package yijiagou.main;

import yijiagou.factory.BeanFactory;
import yijiagou.service.AccountServiceImpl;

public class main {
    public static void main(String[] args) {
//        AccountServiceImpl  as= (AccountServiceImpl) BeanFactory.getBean("accountService");

        for (int i = 0; i <5 ; i++) {
            AccountServiceImpl  as= (AccountServiceImpl) BeanFactory.getBean("accountService");
            System.out.println(as);
            as.SaveAccount();
        }
//        as.SaveAccount();
    }
}
