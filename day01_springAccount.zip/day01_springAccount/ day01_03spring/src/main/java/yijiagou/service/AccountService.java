package yijiagou.service;
/*业务层的接口*/
public interface AccountService {

    void SaveAccount();
}
