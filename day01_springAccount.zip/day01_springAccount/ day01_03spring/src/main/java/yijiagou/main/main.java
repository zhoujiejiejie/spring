package yijiagou.main;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import yijiagou.dao.AccountDao;
import yijiagou.service.AccountService;
import yijiagou.service.AccountServiceImpl;

public class main {
/*
* 获取spring的IOC核心容器，再根据id获取对象
* */

    public static void main(String[] args) {
       //1.获取核心容器对象
        ApplicationContext ac=new ClassPathXmlApplicationContext("bean.xml");

        //根据id获取bean对象
        AccountService as= (AccountService) ac.getBean("accountService");
        as.SaveAccount();

        AccountDao ao= (AccountDao) ac.getBean("accountDao");
        ao.SaveAccount();

        System.out.println(as);
        System.out.println(ao);
    }
}
