package yijiagou.service;

import org.springframework.stereotype.Component;
import yijiagou.dao.AccountDao;
import yijiagou.dao.AccountDaoImpl;



/*
* 以前的XML配置：<bean id="accountService" class="yijiagou.service.AccountServiceImpl">
               <scop=""  init=method=""  destory-method="">
*              <property ......></property>
*              </bean>
*
*   用于创建对象的
*      @Component:
*       作用：把当前类对象存入spring中
*        属性：value：用于指定bean的id。当我们不写时，他的默认值是当前类名，且首字母该小写
*   用于注入数据的
*
*   用于改变数据范围
*   和生命周期有关
* */

/*业务层实现类*/

@Component
public class AccountServiceImpl implements AccountService {
//业务层调用持久层

    private AccountDao accountDao = new AccountDaoImpl();

    public void SaveAccount() {
//        accountDao.SaveAccount();
        System.out.println("执行了SaveAccount方法！！！！");

    }
}
