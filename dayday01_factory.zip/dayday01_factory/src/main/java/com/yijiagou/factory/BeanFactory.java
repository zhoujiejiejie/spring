package com.yijiagou.factory;
/*
*创建Bean对象的工产
* */
public class BeanFactory {
}
