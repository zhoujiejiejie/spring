package yijiagou.service;

import yijiagou.dao.AccountDao;
import yijiagou.dao.AccountDaoImpl;
import yijiagou.factory.BeanFactory;

/*业务层实现类*/
public class AccountServiceImpl implements AccountService {
//业务层调用持久层

    private AccountDao accountDao = (AccountDao) BeanFactory.getBean("accountDao");

    public void SaveAccount() {
        accountDao.SaveAccount();

    }
}
