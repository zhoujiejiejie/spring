package yijiagou.dao;
/*持久层接口*/
public interface AccountDao {
    void SaveAccount();
}
