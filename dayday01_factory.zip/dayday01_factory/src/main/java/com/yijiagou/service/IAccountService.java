package com.yijiagou.service;
/*
* 业务层的接口
* */
public interface IAccountService {

    /*
    * 模拟保存账户
    * */
    void saveAccount();
}
