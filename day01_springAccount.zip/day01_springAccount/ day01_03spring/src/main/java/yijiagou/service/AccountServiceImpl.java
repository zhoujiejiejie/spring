package yijiagou.service;

import yijiagou.dao.AccountDao;
import yijiagou.dao.AccountDaoImpl;


/*业务层实现类*/
public class AccountServiceImpl implements AccountService {
//业务层调用持久层

    private AccountDao accountDao = new AccountDaoImpl();

    public void SaveAccount() {
        accountDao.SaveAccount();

    }
}
