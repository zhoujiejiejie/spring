package yijiagou.dao;

public class AccountDaoImpl implements AccountDao {
    public void SaveAccount() {
        System.out.println("数据保存了！！！！！！！");
    }
}
